<?php /* Smarty version Smarty-3.1.8, created on 2012-11-02 20:48:51
         compiled from "C:\xampp\htdocs\mvc\views\index\index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20301509423a38df5d5-21788534%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e89cb458b18fccff8d47ced8a90cf0e41446ee15' => 
    array (
      0 => 'C:\\xampp\\htdocs\\mvc\\views\\index\\index.tpl',
      1 => 1335100144,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20301509423a38df5d5-21788534',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_509423a38e14e1_00423349',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_509423a38e14e1_00423349')) {function content_509423a38e14e1_00423349($_smarty_tpl) {?>Hola desde la vista smarty...<?php }} ?>