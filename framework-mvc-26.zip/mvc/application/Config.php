<?php

/*
 * -------------------------------------
 * www.dlancedu.com | Jaisiel Delance
 * framework mvc basico
 * Config.php
 * -------------------------------------
 */


define('BASE_URL', 'http://localhost/mvc/');
define('DEFAULT_CONTROLLER', 'index');
define('DEFAULT_LAYOUT', 'twb');

define('APP_NAME', 'Mi Framework');
define('APP_SLOGAN', 'tutorial MVC y PHP...');
define('APP_COMPANY', 'www.dlancedu.com');
define('SESSION_TIME', 10);
define('HASH_KEY', '4f6a6d832be79');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mvc');
define('DB_CHAR', 'utf8');

?>