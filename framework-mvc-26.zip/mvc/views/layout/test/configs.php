<?php

function get_layout_positions()
{
    return array(
        'header' => array(),
        'top' => array(),
        'sidebar' => array(),
        'footer' => array()
    );
}

?>
