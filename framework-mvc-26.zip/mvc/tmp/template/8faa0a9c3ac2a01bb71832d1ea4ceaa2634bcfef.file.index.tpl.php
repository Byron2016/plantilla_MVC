<?php /* Smarty version Smarty-3.1.8, created on 2013-04-20 17:39:40
         compiled from "/var/www/mvc/views/index/index.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11363953634fca89547a7174-09013864%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8faa0a9c3ac2a01bb71832d1ea4ceaa2634bcfef' => 
    array (
      0 => '/var/www/mvc/views/index/index.tpl',
      1 => 1366493978,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11363953634fca89547a7174-09013864',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.8',
  'unifunc' => 'content_4fca895483ffa1_23941704',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_4fca895483ffa1_23941704')) {function content_4fca895483ffa1_23941704($_smarty_tpl) {?>Hola desde la vista smarty...<?php }} ?>